import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    
    return MaterialApp( 
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData( 
        primarySwatch: Colors.indigo,
      ),
      home: const MyHomepage(),
    );
  }
}

class MyHomepage extends StatefulWidget {
  const MyHomepage({super.key});

  @override
  State<MyHomepage> createState() => _MyHomepageState();
}

class _MyHomepageState extends State<MyHomepage> {
  var wtController =TextEditingController();
  var ftController =TextEditingController();
  var inController =TextEditingController();
  var reasult="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       
      appBar: AppBar( 
        backgroundColor: Colors.red,
        title: Text('Your BMI',style: TextStyle( 
          fontSize: 50
        ),),
      ),
      body: Center(
        child: Container(
          width: 600,
          child: Column( 
            mainAxisAlignment: MainAxisAlignment.center,
            children: [ 
              Text('BMI',style: TextStyle( 
                fontSize: 35
              ),),
              SizedBox( height: 20.0,),
              TextField(
                controller: wtController,
                decoration: InputDecoration( 
                  label: Text('Enter your waight(in kgs)'),
                  prefixIcon: Icon(Icons.line_weight) 
                ),
                keyboardType: TextInputType.number, 
          
              ),
              SizedBox( height: 10.0,),
              TextField(
                controller: ftController,
                decoration: InputDecoration( 
                  label: Text('Enter your Height(in inch)'),
                  prefixIcon: Icon(Icons.height) 
                ),
                keyboardType: TextInputType.number, 
          
              ),
              SizedBox( height: 10.0,),
              TextField( 
                controller: inController,
                decoration: InputDecoration( 
                  label: Text('Enter your Height(in cm)'),
                  prefixIcon: Icon(Icons.height)
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 50.0,),
              ElevatedButton(onPressed: (){ 
                var wt=wtController.text.toString();
                var ft=ftController.text.toString();
                var inch=inController.text.toString();
                if(wt!=""&&ft!=""&&inch!=""){
                  var iwt=int.parse(wt);
                  var ift=int.parse(ft);
                  var inc=int.parse(inch);


                  var tinch=(ift*12)+inc;
                  var tcm=tinch*2.54;
                  var tm=tcm/100;
                  var bmi=iwt/(tm*tm);

                  
                  setState(() {
                    reasult='Your BMI is :$bmi';
                  });

                }
                else{
                  setState(() {
                    reasult="please fill all the requirement";
                  });

                }
              }, child: Text('Calculate',)),
              
              Text(reasult,style: TextStyle(fontSize: 20.0),)
              
            ],
          ),
        ),
      ),
    );
  }
}